#include <iostream>
#include <sstream>

using namespace std;

bool sortAlpha(string s1, string s2) {
    int len = 0;
    if(s1 == s2) return true;
    if(s1.length() < s2.length()) len = s1.length();
    else len = s2.length();

    for(int i = 0; i < len; i++) {
        if(s1[i] < s2[i]) return true;
    }
    return false;
}

string* insertionSort(string arr[], int n) {
    for (int i = 1; i < n; i++) {

        string nextWord = *(arr+i);
        int loc = i;

        while ((loc > 0) && (sortAlpha(nextWord, *(arr + loc - 1)))) {
            arr[loc] = arr[loc - 1];
        }
        
        arr[loc] = nextWord;
        loc--;
    }
    return arr;
}

int main() {
    string input;
    getline(cin, input);
    stringstream ss(input);  

    string tempWord;
    string arr[64];
    int len = 0;
    while (ss >> tempWord) {
        arr[len] = tempWord;
        len++;
    }

    // for(int i = 0 ; i < 64; i++) {
    //     if(arr[i].length() != 0) cout << arr[i] << endl;
    // }
    
    // insertionSort(arr, len);

    int count = 1;
    bool dup = false;
    for(int i = 1; i < len; i++) {
        // cout << *(arr+i) << " " << *(arr+i-1) << endl;
        if(*(arr+i) == *(arr+i-1)) {
            count++;
            dup = true;
        }

        else {
            cout << *(arr+i) << " " << count << endl;
            count = 1;
        }
    }
    if(count) cout << *(arr+len-1) << " " << count << endl;
    if(dup) cout << "There are no duplicates" << endl;
}